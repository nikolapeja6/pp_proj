// generated with ast extension for cup
// version 0.8
// 27/4/2018 1:55:13


package rs.ac.bg.etf.pp1.ast;

public class ConditionListMultiple extends ConditionList {

    private ConditionList ConditionList;
    private ConditionElement ConditionElement;

    public ConditionListMultiple (ConditionList ConditionList, ConditionElement ConditionElement) {
        this.ConditionList=ConditionList;
        if(ConditionList!=null) ConditionList.setParent(this);
        this.ConditionElement=ConditionElement;
        if(ConditionElement!=null) ConditionElement.setParent(this);
    }

    public ConditionList getConditionList() {
        return ConditionList;
    }

    public void setConditionList(ConditionList ConditionList) {
        this.ConditionList=ConditionList;
    }

    public ConditionElement getConditionElement() {
        return ConditionElement;
    }

    public void setConditionElement(ConditionElement ConditionElement) {
        this.ConditionElement=ConditionElement;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ConditionList!=null) ConditionList.accept(visitor);
        if(ConditionElement!=null) ConditionElement.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ConditionList!=null) ConditionList.traverseTopDown(visitor);
        if(ConditionElement!=null) ConditionElement.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ConditionList!=null) ConditionList.traverseBottomUp(visitor);
        if(ConditionElement!=null) ConditionElement.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ConditionListMultiple(\n");

        if(ConditionList!=null)
            buffer.append(ConditionList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ConditionElement!=null)
            buffer.append(ConditionElement.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ConditionListMultiple]");
        return buffer.toString();
    }
}
