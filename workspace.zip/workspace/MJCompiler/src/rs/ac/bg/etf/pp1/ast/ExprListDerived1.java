// generated with ast extension for cup
// version 0.8
// 27/4/2018 1:55:13


package rs.ac.bg.etf.pp1.ast;

public class ExprListDerived1 extends ExprList {

    private ExprList ExprList;
    private ExprElement ExprElement;

    public ExprListDerived1 (ExprList ExprList, ExprElement ExprElement) {
        this.ExprList=ExprList;
        if(ExprList!=null) ExprList.setParent(this);
        this.ExprElement=ExprElement;
        if(ExprElement!=null) ExprElement.setParent(this);
    }

    public ExprList getExprList() {
        return ExprList;
    }

    public void setExprList(ExprList ExprList) {
        this.ExprList=ExprList;
    }

    public ExprElement getExprElement() {
        return ExprElement;
    }

    public void setExprElement(ExprElement ExprElement) {
        this.ExprElement=ExprElement;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ExprList!=null) ExprList.accept(visitor);
        if(ExprElement!=null) ExprElement.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ExprList!=null) ExprList.traverseTopDown(visitor);
        if(ExprElement!=null) ExprElement.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ExprList!=null) ExprList.traverseBottomUp(visitor);
        if(ExprElement!=null) ExprElement.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ExprListDerived1(\n");

        if(ExprList!=null)
            buffer.append(ExprList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ExprElement!=null)
            buffer.append(ExprElement.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ExprListDerived1]");
        return buffer.toString();
    }
}
